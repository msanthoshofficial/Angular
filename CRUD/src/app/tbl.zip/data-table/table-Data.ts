const tableData = [
  {"name":'santhosh M', "location":'chennai', "age":'20'},
  {"name":'Mothesh M', "location":'madurai', "age":'15'},
  {"name":'Naren M', "location":'trichy', "age":'17'}
]
export default tableData;
